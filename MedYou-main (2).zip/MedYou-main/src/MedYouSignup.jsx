// src/MedYouSignup.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./MedYouSignup.css";

export const MedYouSignup = () => {
  const [form, setForm] = useState({
    fullName: "",
    healthCard: "",
    closestPharmacy: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [status, setStatus] = useState("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleFindPharmacy = () => {
    const fallbackUrl =
      "https://www.google.com/maps/search/pharmacy+near+me";

    if (navigator && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          const url = `https://www.google.com/maps/search/pharmacy/@${latitude},${longitude},15z`;
          window.open(url, "_blank", "noopener,noreferrer");
        },
        () => {
          window.open(fallbackUrl, "_blank", "noopener,noreferrer");
        },
        { timeout: 8000 }
      );
    } else {
      window.open(fallbackUrl, "_blank", "noopener,noreferrer");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (form.password !== form.confirmPassword) {
      setStatus("error");
      setErrorMsg("Passwords do not match.");
      return;
    }

    setStatus("loading");
    setErrorMsg("");

    try {
      const res = await fetch("http://localhost:4000/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: form.fullName,
          healthCard: form.healthCard,
          closestPharmacy: form.closestPharmacy,
          phone: form.phone,
          email: form.email,
          password: form.password,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setStatus("error");
        setErrorMsg(data.error || "Could not create account.");
        return;
      }

      const data = await res.json();

      localStorage.setItem("medyou_token", data.token);
      localStorage.setItem("medyou_account", JSON.stringify(data.account));
      localStorage.setItem("medyou_account_email", data.account.email);

      setStatus("success");

      setTimeout(() => {
        navigate("/dashboard");
      }, 1200);
    } catch (err) {
      console.error(err);
      setStatus("error");
      setErrorMsg("Network error. Is the MedYou backend running on :4000?");
    }
  };

  return (
    <div className="signup-root">
      <div className="signup-orb signup-orb--teal"></div>
      <div className="signup-orb signup-orb--peach"></div>
      <div className="signup-orb signup-orb--mint"></div>

      <div className="signup-card">
        <header className="signup-header">
          <div className="signup-logo-mark">
            <span>M</span>
          </div>
          <div className="signup-logo-text">
            <span>MedYou Health</span>
          </div>
        </header>

        <div className="signup-content">
          <h1>Create your MedYou profile</h1>
          <p className="signup-subtitle">
            Just the basics we need to sync with your pharmacy and keep you safe.
          </p>

          <form className="signup-form" onSubmit={handleSubmit}>
            {/* Full name – full row */}
            <div className="form-group full-width">
              <label>
                Full Name <span className="required">Required</span>
                <input
                  type="text"
                  name="fullName"
                  value={form.fullName}
                  onChange={handleChange}
                  required
                  placeholder="e.g. Sara Test"
                  className="form-input"
                />
              </label>
            </div>

            {/* Health Card – its own row now */}
            <div className="form-group full-width">
              <label>
                Health Card Number <span className="required">Required</span>
                <input
                  type="text"
                  name="healthCard"
                  value={form.healthCard}
                  onChange={handleChange}
                  required
                  placeholder="e.g. ABC 123 567"
                  className="form-input"
                />
                <div className="hint">
                  <svg
                    className="hint-icon"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
                  </svg>
                  Try: <code>ABC1234567</code>, <code>ON99887766</code>, or{" "}
                  <code>BC44556677</code>
                </div>
              </label>
            </div>

            {/* Closest Pharmacy – full-width row with Google Maps button */}
            <div className="form-group full-width">
              <label>
                Closest Pharmacy <span className="required">Required</span>
                <div className="input-with-addon">
                  <input
                    type="text"
                    name="closestPharmacy"
                    value={form.closestPharmacy}
                    onChange={handleChange}
                    required
                    placeholder="e.g. Shoppers at Dundas & Mississauga"
                    className="form-input"
                  />
                  <button
                    type="button"
                    className="maps-button"
                    onClick={handleFindPharmacy}
                  >
                    <span className="maps-dot" />
                    Use Google Maps
                  </button>
                </div>
                <div className="field-helper">
                  We’ll still save exactly what you type above.
                </div>
              </label>
            </div>

            {/* Phone + Email row (unchanged) */}
            <div className="form-row">
              <div className="form-group">
                <label>
                  Phone Number <span className="required">Required</span>
                  <input
                    type="tel"
                    name="phone"
                    value={form.phone}
                    onChange={handleChange}
                    required
                    placeholder="e.g. 647-555-1234"
                    className="form-input"
                  />
                </label>
              </div>

              <div className="form-group">
                <label>
                  Email Address <span className="required">Required</span>
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    required
                    placeholder="you@example.com"
                    className="form-input"
                  />
                </label>
              </div>
            </div>

            {/* Password row (unchanged) */}
            <div className="form-row">
              <div className="form-group">
                <label>
                  Password <span className="required">Required</span>
                  <input
                    type="password"
                    name="password"
                    value={form.password}
                    onChange={handleChange}
                    required
                    placeholder="At least 8 characters"
                    className="form-input"
                  />
                </label>
              </div>

              <div className="form-group">
                <label>
                  Confirm Password <span className="required">Required</span>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    required
                    placeholder="Re-type password"
                    className="form-input"
                  />
                </label>
              </div>
            </div>

            {status === "error" && (
              <div className="status-error">
                <svg
                  className="status-icon"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" />
                </svg>
                {errorMsg}
              </div>
            )}

            {status === "success" && (
              <div className="status-success">
                <svg
                  className="status-icon"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                </svg>
                Profile created! Loading your dashboard…
              </div>
            )}

            <button
              type="submit"
              className="signup-submit"
              disabled={status === "loading"}
            >
              {status === "loading" ? (
                <span className="button-content">
                  <span className="loading-spinner"></span>
                  Creating profile…
                </span>
              ) : (
                "Create account"
              )}
            </button>
          </form>

          <p className="signup-footer">
            Already using MedYou? <Link to="/login">Log in instead</Link>
          </p>
        </div>
      </div>
    </div>
  );
};
