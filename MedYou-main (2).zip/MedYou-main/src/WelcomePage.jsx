import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./WelcomePage.css";

const TYPED_WORDS = ["prescriptions", "refills", "screenings", "symptom checks"];

export const WelcomePage = () => {
  const [wordIndex, setWordIndex] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentWord = TYPED_WORDS[wordIndex];
    const typingSpeed = isDeleting ? 40 : 90;
    const pauseAtEnd = 1300;

    const timeout = setTimeout(() => {
      if (!isDeleting && displayed.length < currentWord.length) {
        setDisplayed(currentWord.slice(0, displayed.length + 1));
      } else if (!isDeleting && displayed.length === currentWord.length) {
        setTimeout(() => setIsDeleting(true), pauseAtEnd);
      } else if (isDeleting && displayed.length > 0) {
        setDisplayed(currentWord.slice(0, displayed.length - 1));
      } else if (isDeleting && displayed.length === 0) {
        setIsDeleting(false);
        setWordIndex((prev) => (prev + 1) % TYPED_WORDS.length);
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [displayed, isDeleting, wordIndex]);

  return (
    <div className="hero-root">
      {/* floating background orbs */}
      <div className="hero-orb hero-orb--teal" />
      <div className="hero-orb hero-orb--peach" />
      <div className="hero-orb hero-orb--mint" />

      <div className="hero-shell">
        <section className="hero-card">
          <div className="hero-card-top">
            <div className="hero-brand-row">
              <div className="hero-logo">
                <span>M</span>
              </div>
              <div>
                <div className="hero-brand-name">MedYou Health</div>
                <div className="hero-brand-sub">
                  Patient-first medication companion
                </div>
              </div>
              <span className="hero-badge">Built with pharmacists</span>
            </div>

            <div className="hero-tag-row">
              <span className="hero-tag hero-tag--soft">
                For patients who never want to miss a dose again.
              </span>
              <span className="hero-status-pill">
                <span className="hero-status-dot" />
                Med sync ready
              </span>
            </div>

            <h1 className="hero-title">
              All your{" "}
              <span className="hero-typed">
                {displayed}
                <span className="hero-cursor">|</span>
                <span className="hero-typed-underline" />
              </span>{" "}
              in one place.
            </h1>

            <p className="hero-subtitle">
              MedYou connects your health card, prescriptions, and closest
              pharmacy into a single view. Smart reminders, refill requests, and
              symptom screening that escalate to real clinicians when something
              looks off.
            </p>

            <ul className="hero-bullets">
              <li>Automatic reminders when meds or prescriptions are about to run out.</li>
              <li>Refill requests routed straight to your preferred pharmacy.</li>
              <li>Symptom logging with photo upload and “see-a-pharmacist-now” flags.</li>
              <li>Secure view of your medical history linked to your health card.</li>
            </ul>
          </div>

          <div className="hero-card-bottom">
            <div className="hero-cta-row">
              <Link to="/signup" className="hero-btn primary">
                Get started
              </Link>
              <Link to="/login" className="hero-btn ghost">
                Log in
              </Link>
            </div>
            <p className="hero-helper">
              No app download. Just your health card and email.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};
