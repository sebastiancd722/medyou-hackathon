// src/Dashboard.jsx
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Dashboard.css";
import TreatmentFlow from "./checkin/TreatmentFlow";

// ====== STATIC OTC CATALOG ======
const OTC_CATEGORIES = [
  { id: "all", label: "All conditions" },
  { id: "pain", label: "Pain & fever" },
  { id: "cold", label: "Cold, flu & cough" },
  { id: "allergy", label: "Allergy" },
  { id: "stomach", label: "Stomach & digestion" },
  { id: "skin", label: "Skin & topical" },
  { id: "supplements", label: "Vitamins & wellness" },
];

const OTC_MEDICATIONS = [
  // --- PAIN ---
  {
    id: "acetaminophen-regular",
    name: "Acetaminophen",
    brandHint: "Tylenol®-style",
    strength: "325 mg",
    form: "Tablets",
    category: "pain",
    tags: ["headache", "fever", "muscle pain"],
    commonUse: "Mild to moderate pain and fever relief.",
    caution:
      "Follow maximum daily dose. Avoid combining with other acetaminophen products.",
    badges: ["Gentle on stomach", "Popular choice"],
  },
  {
    id: "ibuprofen-200",
    name: "Ibuprofen",
    brandHint: "Advil® / Motrin®-style",
    strength: "200 mg",
    form: "Tablets / caplets",
    category: "pain",
    tags: ["inflammation", "joint pain", "cramps"],
    commonUse: "Pain with inflammation, such as joint and muscle pain.",
    caution:
      "Take with food. Ask your doctor if you have kidney, heart, or stomach issues.",
    badges: ["Anti-inflammatory"],
  },
  {
    id: "naproxen-220",
    name: "Naproxen",
    brandHint: "Aleve®-style",
    strength: "220 mg",
    form: "Caplets",
    category: "pain",
    tags: ["long-lasting", "arthritis"],
    commonUse: "Longer-acting relief for joint and muscle pain.",
    caution: "Take with food. Check with your provider if you’re on blood thinners.",
    badges: ["Long-acting"],
  },
  {
    id: "acetaminophen-extra",
    name: "Acetaminophen Extra Strength",
    brandHint: "Tylenol® Extra Strength",
    strength: "500 mg",
    form: "Caplets",
    category: "pain",
    tags: ["strong pain", "fever"],
    commonUse: "Stronger relief for headaches, muscle aches, and fevers.",
    caution: "Strictly adhere to daily limits to avoid liver damage.",
    badges: ["High potency"],
  },
  {
    id: "muscle-back-relief",
    name: "Muscle & Back Relief",
    brandHint: "Robaxacet®-style",
    strength: "Methocarbamol 400mg",
    form: "Tablets",
    category: "pain",
    tags: ["back pain", "muscle spasm"],
    commonUse: "Relief of muscle spasms and associated pain.",
    caution: "May cause drowsiness. Do not drive after taking.",
    badges: ["Muscle relaxant"],
  },

  // --- COLD & FLU ---
  {
    id: "daytime-cold-relief",
    name: "Daytime Cold & Flu Relief",
    brandHint: "DayQuil®-style",
    strength: "Multi-ingredient",
    form: "Liquid / capsules",
    category: "cold",
    tags: ["cold", "flu", "daytime"],
    commonUse: "Relief of daytime cold and flu symptoms without drowsiness.",
    caution: "Check for acetaminophen duplication with other products.",
    badges: ["Non-drowsy"],
  },
  {
    id: "nighttime-cold-relief",
    name: "Nighttime Cold & Flu Relief",
    brandHint: "NyQuil®-style",
    strength: "Multi-ingredient",
    form: "Liquid / capsules",
    category: "cold",
    tags: ["cold", "flu", "nighttime"],
    commonUse: "Helps with sleep when cold and flu symptoms keep you up.",
    caution: "May cause drowsiness. Avoid alcohol and driving.",
    badges: ["For sleep"],
  },
  {
    id: "saline-nasal-spray",
    name: "Saline Nasal Spray",
    brandHint: "Generic saline",
    strength: "0.65%",
    form: "Nasal spray",
    category: "cold",
    tags: ["congestion", "dry nose"],
    commonUse: "Moisturizes dry nasal passages and helps clear congestion.",
    caution: "Generally safe. Follow package instructions.",
    badges: ["Non-medicated"],
  },

  // --- ALLERGY ---
  {
    id: "cetirizine-10",
    name: "Cetirizine",
    brandHint: "Reactine®-style",
    strength: "10 mg",
    form: "Tablets",
    category: "allergy",
    tags: ["seasonal allergies", "itchy eyes"],
    commonUse: "Allergic rhinitis and itchy eyes relief.",
    caution: "May cause mild drowsiness in some people.",
    badges: ["Once daily"],
  },
  {
    id: "loratadine-10",
    name: "Loratadine",
    brandHint: "Claritin®-style",
    strength: "10 mg",
    form: "Tablets",
    category: "allergy",
    tags: ["hay fever", "allergic rhinitis"],
    commonUse: "Non-drowsy allergy relief.",
    caution: "Consult if you have liver disease.",
    badges: ["Non-drowsy"],
  },
  {
    id: "fluticasone-nasal",
    name: "Fluticasone Nasal Spray",
    brandHint: "Flonase®-style",
    strength: "50 mcg",
    form: "Nasal spray",
    category: "allergy",
    tags: ["stuffy nose", "allergy prevention"],
    commonUse: "Prevents and relieves allergy-related nasal symptoms.",
    caution: "Use regularly for best effect. Ask pharmacist about long-term use.",
    badges: ["Preventive"],
  },

  // --- STOMACH ---
  {
    id: "antacid-chew",
    name: "Antacid Chewable Tablets",
    brandHint: "Tums®-style",
    strength: "Calcium carbonate 500 mg",
    form: "Chewable tablets",
    category: "stomach",
    tags: ["heartburn", "indigestion"],
    commonUse: "Quick relief of heartburn and sour stomach.",
    caution: "Watch total calcium intake if on supplements.",
    badges: ["Fast-acting"],
  },
  {
    id: "famotidine-20",
    name: "Famotidine",
    brandHint: "Pepcid AC®-style",
    strength: "20 mg",
    form: "Tablets",
    category: "stomach",
    tags: ["heartburn prevention"],
    commonUse: "Prevents and relieves heartburn associated with acid indigestion.",
    caution: "Ask your doctor if using longer than 2 weeks.",
    badges: ["Pre-emptive"],
  },

  // --- SKIN / TOPICAL ---
  {
    id: "hydrocortisone-cream",
    name: "Hydrocortisone Cream",
    brandHint: "Cortate®-style",
    strength: "0.5% / 1%",
    form: "Topical cream",
    category: "skin",
    tags: ["itch", "rash"],
    commonUse: "Temporary relief of minor skin irritations and rashes.",
    caution: "Avoid long-term use on large areas without medical advice.",
    badges: ["Targeted relief"],
  },
  {
    id: "triple-antibiotic",
    name: "Triple Antibiotic Ointment",
    brandHint: "Polysporin®-style",
    strength: "Multi-ingredient",
    form: "Ointment",
    category: "skin",
    tags: ["cuts", "scrapes"],
    commonUse: "Prevents infection in minor cuts, scrapes, and burns.",
    caution: "Stop use if rash or irritation develops.",
    badges: ["First-aid staple"],
  },

  // --- SUPPLEMENTS ---
  {
    id: "vitamin-d-1000",
    name: "Vitamin D",
    brandHint: "Vitamin D3",
    strength: "1000 IU",
    form: "Softgels / tablets",
    category: "supplements",
    tags: ["bone health", "immune"],
    commonUse: "Supports bone health and immune function.",
    caution: "Check with your doctor for high doses.",
    badges: ["Daily support"],
  },
  {
    id: "vitamin-b-complex",
    name: "Vitamin B-Complex",
    brandHint: "B-Complex",
    strength: "Varied",
    form: "Tablets / capsules",
    category: "supplements",
    tags: ["energy", "stress"],
    commonUse: "Helps support energy metabolism and stress response.",
    caution: "May cause bright yellow urine (normal).",
    badges: ["Energy support"],
  },
  {
    id: "magnesium-oxide",
    name: "Magnesium",
    brandHint: "Magnesium oxide",
    strength: "250-400 mg",
    form: "Tablets",
    category: "supplements",
    tags: ["muscle function", "relaxation"],
    commonUse:
      "Helps in tissue formation and proper muscle function.",
    caution: "May cause loose stools at higher doses.",
    badges: ["Muscle support"],
  },
];

// ====== SIMPLE DAILY SCHEDULE HELPERS FOR PILL TRACKING ======
const SCHEDULE_SLOTS = [
  { id: "morning", label: "Morning", time: "08:00" },
  { id: "midday", label: "Midday", time: "12:00" },
  { id: "evening", label: "Evening", time: "18:00" },
  { id: "bedtime", label: "Bedtime", time: "22:00" },
];

const getDateKey = (date = new Date()) => date.toISOString().slice(0, 10);

/**
 * Build a simple schedule for a prescription based on how many times per day
 * it should be taken. For now we just map 1–4 daily doses onto
 * Morning / Midday / Evening / Bedtime.
 */
const buildScheduleForRx = (rx) => {
  const dosesPerDay =
    typeof rx.dailyDoses === "number" && rx.dailyDoses > 0 ? rx.dailyDoses : 1;
  return SCHEDULE_SLOTS.slice(0, Math.min(dosesPerDay, SCHEDULE_SLOTS.length));
};

export const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [prescriptions, setPrescriptions] = useState([]);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");
  const [showCheckin, setShowCheckin] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("today"); // 'today' | 'browse'
  const [toastMessage, setToastMessage] = useState("");
  const [toastVisible, setToastVisible] = useState(false);
  const [pillLog, setPillLog] = useState({});

  // browse tab state
  const [selectedCondition, setSelectedCondition] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [otcCart, setOtcCart] = useState([]);

  // discussion list state
  const [discussionList, setDiscussionList] = useState([]);

  const navigate = useNavigate();

  // ====== LOAD REAL PRESCRIPTIONS & HISTORY FROM BACKEND ======
  useEffect(() => {
    const token = localStorage.getItem("medyou_token");
    if (!token) {
      setError("You need to log in to view your dashboard.");
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        const headers = {
          Authorization: `Bearer ${token}`,
        };

        // correct routes: /api/me/prescriptions and /api/me/history
        const [rxRes, hxRes] = await Promise.all([
          fetch("http://localhost:4000/api/me/prescriptions", { headers }),
          fetch("http://localhost:4000/api/me/history", { headers }),
        ]);

        if (!rxRes.ok || !hxRes.ok) {
          throw new Error("Failed to load prescriptions or history.");
        }

        const rxData = await rxRes.json();
        const hxData = await hxRes.json();

        setPrescriptions(Array.isArray(rxData.prescriptions) ? rxData.prescriptions : []);
        setHistory(Array.isArray(hxData.history) ? hxData.history : []);
        setError("");
      } catch (err) {
        console.warn("API load failed, using empty data for UI demo", err);
        setPrescriptions([]);
        setHistory([]);
        setError("Could not load your data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // load discussion list from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem("medyou_discussion_list") || "[]";
      const list = JSON.parse(raw);
      setDiscussionList(Array.isArray(list) ? list : []);
    } catch {
      setDiscussionList([]);
    }
  }, []);

  // load pill tracking log from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem("medyou_pill_log");
      if (!raw) {
        setPillLog({});
        return;
      }
      const parsed = JSON.parse(raw);
      setPillLog(parsed && typeof parsed === "object" ? parsed : {});
    } catch {
      setPillLog({});
    }
  }, []);

  // ====== ACCOUNT INFO FROM LOCALSTORAGE ======
  const storedAccount = (() => {
    try {
      const raw = localStorage.getItem("medyou_account");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  })();

  const firstName =
    storedAccount?.patient?.firstName ||
    (storedAccount?.email ? storedAccount.email.split("@")[0] : "there");

  const closestPharmacy = storedAccount?.closestPharmacy || "your pharmacy";

  const avatarInitials = (() => {
    if (storedAccount?.patient?.firstName && storedAccount?.patient?.lastName) {
      return (
        storedAccount.patient.firstName[0] +
        storedAccount.patient.lastName[0]
      ).toUpperCase();
    }
    if (storedAccount?.email) {
      return storedAccount.email.substring(0, 2).toUpperCase();
    }
    return "MY";
  })();

  // ====== SUMMARY METRICS ======
  const todayKey = getDateKey();
  const todayLabel = new Date().toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });

  const summary = (() => {
    let dosesToday = 0;
    let dosesTakenToday = 0;
    let lowStock = 0;

    prescriptions.forEach((rx) => {
      const schedule = buildScheduleForRx(rx);
      dosesToday += schedule.length;

      const rxLog =
        pillLog?.[rx.id]?.[todayKey] || {};
      schedule.forEach((slot) => {
        if (rxLog[slot.id]?.takenAt) {
          dosesTakenToday += 1;
        }
      });

      const remaining =
        typeof rx.remainingPills === "number" ? rx.remainingPills : null;

      if (typeof remaining === "number" && remaining <= 5) {
        lowStock += 1;
      }
    });

    let discussionItems = 0;
    try {
      const list = JSON.parse(
        localStorage.getItem("medyou_discussion_list") || "[]"
      );
      discussionItems = Array.isArray(list) ? list.length : 0;
    } catch {
      discussionItems = 0;
    }

    return { dosesToday, dosesTakenToday, lowStock, discussionItems };
  })();

  // ====== HANDLERS ======
  const handleLogout = () => {
    localStorage.removeItem("medyou_token");
    localStorage.removeItem("medyou_account");
    localStorage.removeItem("medyou_account_email");
    navigate("/login");
  };

  const toggleAccountMenu = () => {
    setAccountMenuOpen((prev) => !prev);
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const showToast = (msg) => {
    setToastMessage(msg);
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 2500);
  };

  // mark/unmark a scheduled dose for today
  const handleToggleDose = (rxId, slotId) => {
    setPillLog((prev) => {
      const dateKey = getDateKey();
      const prevForRx = prev[rxId] || {};
      const prevForDate = prevForRx[dateKey] || {};
      const alreadyTaken = !!prevForDate[slotId];

      const nextForDate = { ...prevForDate };
      if (alreadyTaken) {
        delete nextForDate[slotId];
      } else {
        nextForDate[slotId] = { takenAt: new Date().toISOString() };
      }

      const nextForRx = { ...prevForRx, [dateKey]: nextForDate };
      if (Object.keys(nextForDate).length === 0) {
        delete nextForRx[dateKey];
      }

      const nextLog = { ...prev, [rxId]: nextForRx };
      if (Object.keys(nextForRx).length === 0) {
        delete nextLog[rxId];
      }

      try {
        localStorage.setItem("medyou_pill_log", JSON.stringify(nextLog));
      } catch (e) {
        console.error("Failed to save pill log", e);
      }

      return { ...nextLog };
    });
  };

  // ====== BROWSE TAB HELPERS ======
  const filteredMedications = OTC_MEDICATIONS.filter((med) => {
    const matchCategory =
      selectedCondition === "all" || med.category === selectedCondition;

    const query = searchQuery.trim().toLowerCase();
    if (!query) return matchCategory;

    const inName = med.name.toLowerCase().includes(query);
    const inBrand = med.brandHint.toLowerCase().includes(query);
    const inTags = med.tags.some((tag) =>
      tag.toLowerCase().includes(query)
    );

    return matchCategory && (inName || inBrand || inTags);
  });

  const addToCart = (med) => {
    setOtcCart((prev) => {
      if (prev.some((item) => item.id === med.id)) {
        showToast("Already in cart.");
        return prev;
      }
      const next = [...prev, med];
      showToast("Added to request cart.");
      return next;
    });
  };

  const removeFromCart = (id) => {
    setOtcCart((prev) => prev.filter((item) => item.id !== id));
    showToast("Removed from cart.");
  };

  const handleSendRequest = () => {
    if (otcCart.length === 0) {
      showToast("Your cart is empty.");
      return;
    }

    showToast("Request sent to pharmacy (demo).");
    setOtcCart([]);
  };

  const handleSaveForDiscussion = (med) => {
    try {
      const key = `otc-${med.id}`;
      const label = med.name;
      const note = med.commonUse;

      const raw = localStorage.getItem("medyou_discussion_list") || "[]";
      const list = JSON.parse(raw);
      const safeList = Array.isArray(list) ? list : [];

      if (safeList.some((item) => item.key === key)) {
        showToast("Already in discussion list.");
        setDiscussionList(safeList);
        return;
      }

      const next = [
        ...safeList,
        {
          key,
          type: "otc",
          label,
          note,
        },
      ];

      localStorage.setItem("medyou_discussion_list", JSON.stringify(next));
      setDiscussionList(next);
      showToast("Saved for discussion.");
    } catch (e) {
      console.error(e);
      showToast("Could not save, try again.");
    }
  };

  const handleRemoveDiscussionItem = (key) => {
    try {
      const raw = localStorage.getItem("medyou_discussion_list") || "[]";
      const list = JSON.parse(raw);
      const safeList = Array.isArray(list) ? list : [];
      const next = safeList.filter((item) => item.key !== key);
      localStorage.setItem("medyou_discussion_list", JSON.stringify(next));
      setDiscussionList(next);
      showToast("Removed from discussion list.");
    } catch (e) {
      console.error(e);
      showToast("Could not remove. Try again.");
    }
  };

  return (
    <div className="dashboard-root">
      {/* ====== HEADER ====== */}
      <header className="dashboard-header">
        <div className="dashboard-brand">
          <div className="dashboard-logo-pill" aria-hidden="true">
            💊
          </div>
          <div className="dashboard-logo-text">
            Med<span>You</span>
          </div>
        </div>

        <div className="dashboard-user-menu">
          <button
            type="button"
            className="user-profile-btn"
            onClick={toggleAccountMenu}
            aria-haspopup="true"
            aria-expanded={accountMenuOpen ? "true" : "false"}
          >
            <span className="user-profile-name">
              {storedAccount?.patient?.firstName
                ? `Hi, ${storedAccount.patient.firstName}`
                : storedAccount?.email || "Demo user"}
            </span>
            <div className="user-avatar" aria-hidden="true">
              {avatarInitials}
            </div>
            <span className="dropdown-arrow">▾</span>
          </button>

          {accountMenuOpen && (
            <div className="account-dropdown" role="menu">
              <button
                className="menu-item"
                type="button"
                onClick={() => showToast("Account settings coming soon")}
              >
                My account
              </button>
              <button
                className="menu-item"
                type="button"
                onClick={() =>
                  showToast("Profile customization coming soon")
                }
              >
                Profile &amp; settings
              </button>
              <div className="menu-divider" />
              <button
                className="menu-item text-red"
                type="button"
                onClick={handleLogout}
              >
                Sign out
              </button>
            </div>
          )}
        </div>
      </header>

      {/* ====== TABS ====== */}
      <nav className="app-tabs" role="tablist">
        <button
          className={`tab-btn ${activeTab === "today" ? "active" : ""}`}
          role="tab"
          aria-selected={activeTab === "today"}
          onClick={() => handleTabChange("today")}
        >
          Today
        </button>
        <button
          className={`tab-btn ${activeTab === "browse" ? "active" : ""}`}
          role="tab"
          aria-selected={activeTab === "browse"}
          onClick={() => handleTabChange("browse")}
        >
          Browse medications
        </button>
      </nav>

      <main className="dashboard-main">
        {/* ====== TODAY TAB ====== */}
        {activeTab === "today" && (
          <>
            <section className="dashboard-hero">
              <div className="hero-left">
                <h1 className="hero-title">
                  Morning check-in, <span>{firstName}</span>
                </h1>
                <p className="hero-subtitle">
                  Track your daily medications, review your history, and
                  quickly request help from your pharmacy.
                </p>

                <div className="hero-actions">
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => setShowCheckin(true)}
                  >
                    Start a symptom check
                  </button>
                  <Link to="/" className="btn-ghost">
                    Back to welcome
                  </Link>
                </div>
              </div>

              <div className="hero-right">
                <div className="summary-pill">
                  <span className="summary-pill-label">Linked pharmacy</span>
                  <span className="summary-pill-value">
                    {closestPharmacy}
                  </span>
                </div>
                <div className="summary-grid">
                  <div className="summary-card">
                    <div className="summary-icon-wrapper bg-blue">
                      <span className="summary-icon">📊</span>
                    </div>
                    <div className="summary-text">
                      <span className="summary-label">Doses today</span>
                      <span className="summary-value">
                        {prescriptions.length === 0 && !loading
                          ? "--"
                          : `${summary.dosesTakenToday}/${summary.dosesToday || 0}`}
                      </span>
                      <span className="summary-subtext">
                        Tap a dose in your schedule as you take it.
                      </span>
                    </div>
                  </div>

                  <div className="summary-card">
                    <div className="summary-icon-wrapper bg-orange">
                      <span className="summary-icon">⚠️</span>
                    </div>
                    <div className="summary-text">
                      <span className="summary-label">
                        Prescriptions low on supply
                      </span>
                      <span className="summary-value">
                        {summary.lowStock}
                      </span>
                    </div>
                  </div>

                  <div className="summary-card">
                    <div className="summary-icon-wrapper bg-teal">
                      <span className="summary-icon">💬</span>
                    </div>
                    <div className="summary-text">
                      <span className="summary-label">
                        Saved for discussion
                      </span>
                      <span className="summary-value">
                        {summary.discussionItems}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* GRID: PRESCRIPTIONS + HISTORY */}
            <section className="dashboard-grid">
              <div className="dashboard-card">
                <div className="dashboard-card-header">
                  <h2>My medications</h2>
                  <span className="pill pill-green">
                    {prescriptions.length} on file
                  </span>
                </div>

                {loading && <p className="muted">Loading prescriptions…</p>}
                {!loading && prescriptions.length === 0 && !error && (
                  <p className="muted">No prescriptions found.</p>
                )}
                {!loading && prescriptions.length > 0 && (
                  <ul className="list">
                    {prescriptions.map((rx) => {
                      const schedule = buildScheduleForRx(rx);
                      const rxLogForToday = pillLog?.[rx.id]?.[todayKey] || {};

                      return (
                        <li key={rx.id} className="list-item">
                          <div className="list-title">
                            {rx.drug}{" "}
                            {rx.strength && (
                              <span className="list-strength">
                                {rx.strength}
                              </span>
                            )}
                          </div>
                          {rx.directions && (
                            <div className="list-sub">
                              Sig: {rx.directions}
                            </div>
                          )}
                          <div className="list-meta">
                            {rx.prescriber && (
                              <span>Prescriber: {rx.prescriber}</span>
                            )}
                            {rx.pharmacy?.name && (
                              <span className="list-meta-pill">
                                {rx.pharmacy.name}
                              </span>
                            )}
                          </div>

                          {schedule.length > 0 && (
                            <div className="dose-row">
                              <div className="dose-row-header">
                                <span className="dose-row-label">
                                  Today&apos;s doses
                                </span>
                                <span className="dose-row-date">
                                  {todayLabel}
                                </span>
                              </div>
                              <div className="dose-pill-row">
                                {schedule.map((slot) => {
                                  const logEntry = rxLogForToday[slot.id];
                                  const isTaken = !!logEntry;
                                  const takenLabel = logEntry
                                    ? new Date(
                                        logEntry.takenAt
                                      ).toLocaleTimeString(undefined, {
                                        hour: "numeric",
                                        minute: "2-digit",
                                      })
                                    : null;

                                  return (
                                    <button
                                      key={slot.id}
                                      type="button"
                                      className={`dose-pill-btn ${
                                        isTaken ? "dose-pill-btn--taken" : ""
                                      }`}
                                      onClick={() =>
                                        handleToggleDose(rx.id, slot.id)
                                      }
                                    >
                                      <span className="dose-pill-time">
                                        {slot.label}
                                      </span>
                                      <span className="dose-pill-status">
                                        {isTaken
                                          ? `Taken at ${takenLabel}`
                                          : "Tap when taken"}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>

              <div className="dashboard-card">
                <div className="dashboard-card-header">
                  <h2>Medical history</h2>
                  <span className="pill pill-blue">
                    {history.length} items linked
                  </span>
                </div>

                {loading && <p className="muted">Loading history…</p>}
                {!loading && history.length === 0 && !error && (
                  <p className="muted">No linked history yet.</p>
                )}
                {!loading && history.length > 0 && (
                  <ul className="history-list">
                    {history.map((item) => (
                      <li key={item.id} className="history-item">
                        <div className="history-main">
                          <div className="history-title">{item.title}</div>
                          {item.description && (
                            <div className="history-sub">
                              {item.description}
                            </div>
                          )}
                        </div>
                        <div className="history-meta">
                          {item.date && (
                            <span className="history-meta-pill">
                              {item.date}
                            </span>
                          )}
                          {item.type && (
                            <span className="history-tag">
                              {item.type}
                            </span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </section>

            {/* ERROR MESSAGE IF NEEDED */}
            {error && (
              <section className="dashboard-error">
                <p>{error}</p>
              </section>
            )}
          </>
        )}

        {/* ====== BROWSE TAB ====== */}
        {activeTab === "browse" && (
          <section className="browse-section">
            <header className="browse-header">
              <div>
                <h2>Browse over-the-counter medications</h2>
                <p className="browse-subtitle">
                  Build a cart to send as a request to{" "}
                  <strong>{closestPharmacy}</strong> or save items to your
                  discussion list.
                </p>
              </div>
              <div className="browse-header-meta">
                <span className="badge-soft">
                  {filteredMedications.length} match
                  {filteredMedications.length === 1 ? "" : "es"}
                </span>
              </div>
            </header>

            <div className="browse-layout">
              {/* LEFT: FILTERS */}
              <aside className="browse-filters">
                <div className="dashboard-card">
                  <h3 className="browse-filter-title">Condition</h3>
                  <div className="browse-filter-pills">
                    {OTC_CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        className={`condition-pill ${
                          selectedCondition === cat.id ? "active" : ""
                        }`}
                        onClick={() => setSelectedCondition(cat.id)}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="dashboard-card">
                  <h3 className="browse-filter-title">Search</h3>
                  <div className="browse-search-wrapper">
                    <span className="browse-search-icon" aria-hidden="true">
                      🔍
                    </span>
                    <input
                      type="text"
                      className="browse-search-input"
                      placeholder="Search by name, brand, or symptom"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <p className="browse-search-hint">
                    Ask your pharmacist before starting anything new, especially
                    if you take other medications.
                  </p>
                </div>
              </aside>

              {/* CENTER: RESULTS */}
              <div className="browse-results">
                {filteredMedications.length === 0 ? (
                  <div className="browse-empty">
                    <p className="browse-empty-title">No matches.</p>
                    <p className="browse-empty-text">
                      Try a different symptom keyword or remove some filters.
                    </p>
                  </div>
                ) : (
                  <div className="browse-grid">
                    {filteredMedications.map((med) => (
                      <article key={med.id} className="browse-card">
                        <header className="browse-card-header">
                          <h3 className="browse-card-title">{med.name}</h3>
                          <p className="browse-card-brand">
                            {med.brandHint}
                          </p>
                        </header>
                        <p className="browse-card-sub">
                          {med.strength} • {med.form}
                        </p>
                        <p className="browse-card-use">
                          {med.commonUse}
                        </p>
                        <p className="browse-card-caution">
                          {med.caution}
                        </p>
                        <div className="browse-card-tags">
                          {med.badges.map((badge) => (
                            <span key={badge} className="browse-badge">
                              {badge}
                            </span>
                          ))}
                        </div>
                        <div className="browse-card-tags">
                          {med.tags.map((tag) => (
                            <span key={tag} className="browse-tag">
                              {tag}
                            </span>
                          ))}
                        </div>
                        <div className="med-actions">
                          <button
                            type="button"
                            className="btn-primary med-action-btn"
                            onClick={() => addToCart(med)}
                          >
                            Add to Cart
                          </button>
                          <button
                            type="button"
                            className="btn-ghost med-action-btn"
                            onClick={() => handleSaveForDiscussion(med)}
                          >
                            Discuss
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </div>

              {/* RIGHT: CART + DISCUSSION LIST AS SEPARATE CARDS */}
              <div className="browse-right-column">
                {/* CART CARD */}
                <aside className="dashboard-card cart-panel">
                  <div className="cart-header">
                    <div>
                      <h2>Request Cart</h2>
                      <p className="cart-subtitle">
                        Draft for <strong>{closestPharmacy}</strong>
                      </p>
                    </div>
                    <span className="badge-soft">
                      {otcCart.length} item
                      {otcCart.length === 1 ? "" : "s"}
                    </span>
                  </div>

                  {otcCart.length === 0 ? (
                    <div className="cart-empty">
                      <div className="cart-empty-icon" aria-hidden="true">
                        🧺
                      </div>
                      <p className="cart-empty-title">Your cart is empty</p>
                      <p className="cart-empty-text">
                        Add medications from the catalog to draft a request.
                      </p>
                    </div>
                  ) : (
                    <>
                      <ul className="cart-list">
                        {otcCart.map((item) => (
                          <li key={item.id} className="cart-item">
                            <div className="cart-item-main">
                              <div className="cart-item-name">{item.name}</div>
                              <div className="cart-item-sub">
                                {item.strength} • {item.form}
                              </div>
                            </div>
                            <button
                              type="button"
                              className="cart-remove-btn"
                              onClick={() => removeFromCart(item.id)}
                              aria-label={`Remove ${item.name} from cart`}
                            >
                              ✕
                            </button>
                          </li>
                        ))}
                      </ul>

                      <div className="cart-footer">
                        <div className="cart-summary-note">
                          <div className="cart-summary-label">
                            Pharmacy Review Required
                          </div>
                          <p>
                            This does not charge your card. Your pharmacist will
                            approve suitability first.
                          </p>
                        </div>
                        <button
                          type="button"
                          className="btn-primary cart-send-btn"
                          onClick={handleSendRequest}
                        >
                          Send Request
                        </button>
                      </div>
                    </>
                  )}
                </aside>

                {/* DISCUSSION LIST CARD - SEPARATE BOX */}
                <aside className="dashboard-card discuss-panel">
                  <div className="discuss-header">
                    <div>
                      <h2>Discussion list</h2>
                      <p className="discuss-subtitle">
                        Saved items to review with your pharmacist or doctor.
                      </p>
                    </div>
                    <span className="badge-soft discuss-badge">
                      {discussionList.length} item
                      {discussionList.length === 1 ? "" : "s"}
                    </span>
                  </div>

                  {discussionList.length === 0 ? (
                    <div className="discuss-empty">
                      <p>
                        Use <strong>Discuss</strong> on a medication to save it
                        here for your next visit.
                      </p>
                    </div>
                  ) : (
                    <ul className="discuss-list">
                      {discussionList.map((item) => (
                        <li key={item.key} className="discuss-item">
                          <div className="discuss-item-main">
                            <div className="discuss-item-name">
                              {item.label}
                            </div>
                            {item.note && (
                              <div className="discuss-item-sub">
                                {item.note}
                              </div>
                            )}
                          </div>
                          <button
                            type="button"
                            className="discuss-remove-btn"
                            onClick={() =>
                              handleRemoveDiscussionItem(item.key)
                            }
                            aria-label={`Remove ${item.label} from discussion list`}
                          >
                            ×
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </aside>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* ====== MEDICATION CHECK-IN OVERLAY ====== */}
      {showCheckin && (
        <div className="checkin-overlay">
          <div className="checkin-modal">
            <TreatmentFlow onClose={() => setShowCheckin(false)} />
          </div>
        </div>
      )}

      {/* ====== TOAST ====== */}
      <div
        className={`toast ${toastVisible ? "show" : ""}`}
        role="alert"
        aria-live="polite"
      >
        {toastMessage}
      </div>
    </div>
  );
};