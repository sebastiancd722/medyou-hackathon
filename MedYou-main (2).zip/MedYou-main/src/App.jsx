// src/App.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import { WelcomePage } from "./WelcomePage.jsx";
import { MedYouSignup } from "./MedYouSignup.jsx";
import { LoginPage } from "./LoginPage.jsx";
import { Dashboard } from "./Dashboard.jsx";

function App() {
  return (
    <Routes>
      {/* Landing / welcome screen */}
      <Route path="/" element={<WelcomePage />} />

      {/* Auth + profile setup */}
      <Route path="/signup" element={<MedYouSignup />} />
      <Route path="/login" element={<LoginPage />} />

      {/* Logged-in view */}
      <Route path="/dashboard" element={<Dashboard />} />
    </Routes>
  );
}

export default App;
