import React from "react";

export default function AnalysisResult({ data, onProceed }) {
  const painLevel = parseInt(data?.answers?.pain_level || "0", 10);
  const symptomsRaw = data?.answers?.symptoms || "";
  const symptoms = symptomsRaw.toLowerCase().trim();

  const hasContraindication =
    symptoms.includes("rash") || symptoms.includes("swelling");
  const hasWarning = painLevel > 6 || symptoms.includes("dizzy");

  let statusLabel = "On track";
  let statusTone = "status-badge-success";
  let statusDescription =
    "Nothing in your responses suggests urgent concerns. You’re progressing as expected, and we’ll still notify your pharmacist.";

  if (hasContraindication) {
    statusLabel = "Potential contraindication";
    statusTone = "status-badge-danger";
    statusDescription =
      "Your symptoms may suggest an allergic reaction or interaction. Contact a healthcare provider as soon as possible or seek urgent care if symptoms worsen.";
  } else if (!hasContraindication && hasWarning) {
    statusLabel = "Follow-up recommended";
    statusTone = "status-badge-warning";
    statusDescription =
      "Your pain level and reported symptoms are slightly outside the expected range. A follow-up check with your pharmacist or doctor is recommended.";
  }

  const adherenceAnswer = data?.answers?.adherence || "Not reported";

  return (
    <div className="card card-elevated">
      {/* Header */}
      <div className="card-header-row">
        <div>
          <h2 className="card-title">Analysis results</h2>
          <p className="card-subtitle">
            MedYou has reviewed your answers and summarized key safety signals
            for your pharmacist.
          </p>
        </div>
        <span className={`status-badge ${statusTone}`}>{statusLabel}</span>
      </div>

      {/* Progress */}
      <div className="progress-card">
        <div className="progress-bar progress-bar-lg">
          <div className="progress-bar-fill" style={{ width: "75%" }} />
        </div>
        <p className="progress-text">
          Your check-in is <span>75% complete</span>. You’re almost done—just
          confirm notification and optional follow-up.
        </p>
      </div>

      {/* Alert */}
      <div className="alert-wrapper">
        <div
          className={
            "alert " +
            (hasContraindication
              ? "alert-danger"
              : hasWarning
              ? "alert-warning"
              : "alert-success")
          }
        >
          <div className="alert-dot" />
          <div>
            <h3>{statusLabel}</h3>
            <p>{statusDescription}</p>
          </div>
        </div>
      </div>

      {/* Summary grid */}
      <div className="summary-grid summary-grid-compact">
        <div className="summary-item">
          <span className="summary-label">Reported pain</span>
          <span className="summary-value">
            {painLevel ? `${painLevel}/10` : "Not reported"}
          </span>
          <span className="summary-hint">
            Pain above 7/10 usually prompts closer review.
          </span>
        </div>

        <div className="summary-item">
          <span className="summary-label">New symptoms</span>
          <span className="summary-value">
            {symptomsRaw.trim() ? symptomsRaw : "None recorded"}
          </span>
          <span className="summary-hint">
            Any rash, swelling, or breathing changes should be taken seriously.
          </span>
        </div>

        <div className="summary-item">
          <span className="summary-label">Adherence</span>
          <span className="summary-value">{adherenceAnswer}</span>
          <span className="summary-hint">
            Staying consistent helps the medication work as expected.
          </span>
        </div>
      </div>

      {/* Footer actions */}
      <div className="card-footer-row">
        <div className="card-footer-note">
          <div className="pill-light">
            This summary will be attached to your prescription profile.
          </div>
        </div>
        <button onClick={onProceed} className="btn-primary full-width-sm">
          Proceed to notify pharmacy
        </button>
      </div>
    </div>
  );
}
