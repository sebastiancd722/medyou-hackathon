import React, { useState } from "react";
import AssessmentSurvey from "./AssessmentSurvey";
import AnalysisResult from "./AnalysisResult";
import NotificationConfirm from "./NotificationConfirm";
import AppointmentBooking from "./AppointmentBooking";

const STEP_META = {
  survey: { index: 1, label: "Assessment survey" },
  analysis: { index: 2, label: "Safety & progress analysis" },
  notification: { index: 3, label: "Notify pharmacy" },
  booking: { index: 4, label: "Book follow-up" },
};

const STEP_ORDER = ["survey", "analysis", "notification", "booking"];

export default function TreatmentFlow({ onClose }) {
  const [step, setStep] = useState("survey");
  const [surveyData, setSurveyData] = useState(null);

  const meta = STEP_META[step];

  const currentIndex = STEP_META[step]?.index || 1;
  const progressPercent = (currentIndex / STEP_ORDER.length) * 100;

  return (
    <div className="checkin-shell">
      {/* Header + stepper */}
      <div className="checkin-header">
        <div>
          <p className="checkin-eyebrow">
            Step {meta.index} of {STEP_ORDER.length} · {meta.label}
          </p>
          <h2 className="checkin-title">Medication check-in</h2>
          <p className="checkin-sub">
            Answer a few quick questions, let MedYou analyze your responses, and
            then notify your pharmacy and book a follow-up—without leaving this
            screen.
          </p>
        </div>
        <button
          type="button"
          className="checkin-close"
          onClick={onClose}
          aria-label="Close check-in"
        >
          ×
        </button>
      </div>

      {/* Visual stepper */}
      <div className="checkin-stepper">
        <div className="checkin-progress-bar">
          <div
            className="checkin-progress-fill"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="checkin-stepper-nodes">
          {STEP_ORDER.map((key) => {
            const s = STEP_META[key];
            const isActive = key === step;
            const isCompleted = s.index < currentIndex;
            return (
              <div key={key} className="checkin-stepper-node">
                <div
                  className={
                    "stepper-dot" +
                    (isCompleted ? " stepper-dot-complete" : "") +
                    (isActive ? " stepper-dot-active" : "")
                  }
                >
                  {isCompleted ? "✓" : s.index}
                </div>
                <span
                  className={
                    "stepper-label" +
                    (isActive ? " stepper-label-active" : "") +
                    (isCompleted ? " stepper-label-complete" : "")
                  }
                >
                  {s.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Body */}
      <div className="checkin-body">
        {step === "survey" && (
          <AssessmentSurvey
            onComplete={(data) => {
              setSurveyData(data);
              setStep("analysis");
            }}
          />
        )}

        {step === "analysis" && surveyData && (
          <AnalysisResult
            data={surveyData}
            onProceed={() => setStep("notification")}
          />
        )}

        {step === "notification" && (
          <NotificationConfirm onBookAppointment={() => setStep("booking")} />
        )}

        {step === "booking" && <AppointmentBooking />}
      </div>

      {/* Footer */}
      <div className="checkin-footer">
        <div className="checkin-footer-left">
          <p className="checkin-footer-text">
            You can exit any time—your progress is saved for this session.
          </p>
        </div>
        <button
          type="button"
          className="checkin-secondary"
          onClick={onClose}
        >
          Close
        </button>
      </div>
    </div>
  );
}
