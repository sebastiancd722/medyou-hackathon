import React, { useState } from "react";

const QUESTIONS = [
  {
    id: "adherence",
    text: "Have you been taking your medication regularly as prescribed?",
    helper:
      "Include missed doses or times you took it later than planned, if any.",
    type: "select",
    options: ["Yes, always", "Mostly", "Sometimes", "No, rarely"],
  },
  {
    id: "symptoms",
    text: "Have you experienced any new symptoms since starting this medication?",
    helper:
      "For example: rash, swelling, dizziness, stomach upset, breathing changes.",
    type: "textarea",
  },
  {
    id: "pain_level",
    text: "On a scale of 1–10, how would you rate your current pain level?",
    helper: "1 = no pain, 10 = worst pain you can imagine.",
    type: "select",
    options: ["1","2","3","4","5","6","7","8","9","10"],
  },
];

export default function AssessmentSurvey({ onComplete }) {
  const [answers, setAnswers] = useState({});
  const [photo, setPhoto] = useState(null);

  const handleInputChange = (id, value) => {
    setAnswers((prev) => ({ ...prev, [id]: value }));
  };

  const handlePhotoChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setPhoto(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete({ answers, photo });
  };

  return (
    <div className="card card-elevated">
      {/* Header */}
      <div className="card-header-row">
        <div>
          <h2 className="card-title">Treatment assessment</h2>
          <p className="card-subtitle">
            Help us understand how you’re doing on{" "}
            <span className="highlight-pill">Amoxicillin 500 mg</span>. This
            takes about 1–2 minutes.
          </p>
        </div>
        <div className="med-pill-tag">
          <span className="med-pill-icon" aria-hidden="true">
            💊
          </span>
          <span className="med-pill-text">Current course</span>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="checkin-form">
        {QUESTIONS.map((q) => (
          <div key={q.id} className="form-group">
            <label className="form-label">
              {q.text}
              <span className="required-indicator">*</span>
            </label>

            {q.type === "select" ? (
              <select
                className="input-field"
                required
                value={answers[q.id] || ""}
                onChange={(e) => handleInputChange(q.id, e.target.value)}
              >
                <option value="">Select an option</option>
                {q.options?.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            ) : q.type === "textarea" ? (
              <textarea
                className="input-field input-textarea"
                required
                rows={4}
                placeholder="Describe any new or unusual symptoms in your own words."
                value={answers[q.id] || ""}
                onChange={(e) => handleInputChange(q.id, e.target.value)}
              />
            ) : (
              <input
                className="input-field"
                required
                value={answers[q.id] || ""}
                onChange={(e) => handleInputChange(q.id, e.target.value)}
              />
            )}

            {q.helper && (
              <p className="field-helper-text">
                {q.helper}
              </p>
            )}
          </div>
        ))}

        {/* Photo upload */}
        <div className="form-group form-group-border">
          <label className="form-label">
            Upload a photo of your condition{" "}
            <span className="field-optional">(optional)</span>
          </label>

          <label className="upload-box">
            <div className="upload-inner">
              <div className="upload-icon" aria-hidden="true" />
              <p className="upload-text">
                <span>Click to upload</span> or drag &amp; drop
              </p>
              <p className="upload-subtext">
                Clear, well-lit photos help your pharmacist understand skin
                changes, swelling, or other visible symptoms.
              </p>
            </div>
            <input
              type="file"
              accept="image/*"
              className="upload-input"
              onChange={handlePhotoChange}
            />
          </label>

          {photo && (
            <p className="upload-selected">
              Selected: <strong>{photo.name}</strong>
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="form-footer-row">
          <div className="card-footer-note">
            <span className="pill-light">
              Your responses are securely shared only with your linked pharmacy.
            </span>
          </div>
          <button type="submit" className="btn-primary full-width-sm">
            Submit assessment
          </button>
        </div>
      </form>
    </div>
  );
}
