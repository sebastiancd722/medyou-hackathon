import React, { useEffect, useState } from "react";

export default function NotificationConfirm({ onBookAppointment }) {
  const [status, setStatus] = useState("sending"); // 'sending' | 'sent'

  useEffect(() => {
    const t = setTimeout(() => setStatus("sent"), 2000);
    return () => clearTimeout(t);
  }, []);

  if (status === "sending") {
    return (
      <div className="card card-center">
        <div className="spinner-wrapper">
          <div className="spinner spinner-md animate-spin" />
        </div>
        <h2 className="card-title">Sending assessment…</h2>
        <p className="card-subtitle">
          Securely transmitting your answers and any photo you attached to your
          linked pharmacy.
        </p>
        <p className="card-subtitle subtle">
          Please don’t close this window until the upload finishes.
        </p>
      </div>
    );
  }

  return (
    <div className="card card-center animate-fade-in">
      <div className="status-badge status-badge-success">Assessment submitted</div>
      <h2 className="card-title">Shared with your pharmacy</h2>
      <p className="card-subtitle wide">
        Your pharmacist has received your latest check-in and will review your
        symptoms, pain level, and adherence along with your prescription
        history.
      </p>

      <div className="next-steps">
        <h3>What happens next</h3>
        <ol className="next-steps-list">
          <li>
            <span className="step-label">1</span>
            <div>
              <strong>Assessment is attached</strong>
              <p>
                We link this check-in to your prescription profile so your care
                team sees the full context.
              </p>
            </div>
          </li>
          <li>
            <span className="step-label">2</span>
            <div>
              <strong>Pharmacist review</strong>
              <p>
                Your pharmacist may adjust recommendations or contact you if
                anything looks concerning.
              </p>
            </div>
          </li>
          <li>
            <span className="step-label">3</span>
            <div>
              <strong>Optional follow-up visit</strong>
              <p>
                You can book a quick conversation now to discuss your symptoms
                in more detail.
              </p>
            </div>
          </li>
        </ol>
      </div>

      <button onClick={onBookAppointment} className="btn-primary full-width">
        Book follow-up appointment
      </button>
    </div>
  );
}
