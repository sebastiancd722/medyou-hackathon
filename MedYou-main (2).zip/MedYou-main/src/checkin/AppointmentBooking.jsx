import React, { useState } from "react";

export default function AppointmentBooking() {
  const [provider, setProvider] = useState("pharmacist");
  const [selectedTime, setSelectedTime] = useState(null);
  const [booked, setBooked] = useState(false);

  const TIMES = [
    { label: "09:00 AM", period: "Morning" },
    { label: "09:30 AM", period: "Morning" },
    { label: "10:00 AM", period: "Morning" },
    { label: "10:30 AM", period: "Morning" },
    { label: "11:00 AM", period: "Morning" },
    { label: "01:00 PM", period: "Afternoon" },
    { label: "01:30 PM", period: "Afternoon" },
    { label: "02:00 PM", period: "Afternoon" },
    { label: "03:30 PM", period: "Afternoon" },
    { label: "04:00 PM", period: "Afternoon" },
  ];

  const handleBook = () => {
    if (selectedTime) {
      setBooked(true);
    }
  };

  if (booked) {
    return (
      <div className="card card-center animate-fade-in">
        <div className="status-badge status-badge-info">
          Appointment booked
        </div>
        <h2 className="card-title">You’re all set</h2>
        <p className="card-subtitle wide">
          We’ve reserved a <strong>{provider}</strong> appointment at{" "}
          <strong>{selectedTime}</strong>. Your pharmacy will send a detailed
          confirmation with visit instructions.
        </p>

        <div className="next-steps compact">
          <h3>What to expect</h3>
          <ul>
            <li>You may receive a text, email, or phone confirmation.</li>
            <li>
              Bring a list of your medications and any recent changes in
              symptoms.
            </li>
            <li>Arrive 5–10 minutes early, if possible.</li>
          </ul>
        </div>
      </div>
    );
  }

  const morningSlots = TIMES.filter((t) => t.period === "Morning");
  const afternoonSlots = TIMES.filter((t) => t.period === "Afternoon");

  return (
    <div className="card card-elevated">
      <div className="card-header-row">
        <div>
          <h2 className="card-title">Book a follow-up</h2>
          <p className="card-subtitle">
            Choose who you’d like to speak with and a time that works for you
            within the next few days.
          </p>
        </div>
        <span className="pill-light">Optional, but recommended</span>
      </div>

      {/* Provider toggle */}
      <div className="provider-toggle" aria-label="Choose provider">
        <button
          type="button"
          className={
            "provider-pill" +
            (provider === "pharmacist" ? " provider-pill-active" : "")
          }
          onClick={() => setProvider("pharmacist")}
        >
          Pharmacist
          <span className="provider-pill-sub">
            Best for medication questions and side effects
          </span>
        </button>
        <button
          type="button"
          className={
            "provider-pill" +
            (provider === "doctor" ? " provider-pill-active" : "")
          }
          onClick={() => setProvider("doctor")}
        >
          Family doctor
          <span className="provider-pill-sub">
            Best for overall care plan and diagnoses
          </span>
        </button>
      </div>

      {/* Time selection */}
      <div className="time-section">
        <p className="card-subtitle">Select a time slot:</p>

        <div className="time-group">
          <div className="time-group-label">Morning</div>
          <div className="time-grid">
            {morningSlots.map((t) => (
              <button
                key={t.label}
                type="button"
                onClick={() => setSelectedTime(t.label)}
                className={
                  "time-slot" +
                  (selectedTime === t.label ? " time-slot-active" : "")
                }
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="time-group">
          <div className="time-group-label">Afternoon</div>
          <div className="time-grid">
            {afternoonSlots.map((t) => (
              <button
                key={t.label}
                type="button"
                onClick={() => setSelectedTime(t.label)}
                className={
                  "time-slot" +
                  (selectedTime === t.label ? " time-slot-active" : "")
                }
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary + action */}
      <div className="booking-summary-row">
        <div className="booking-summary">
          <p className="booking-summary-label">Selected slot</p>
          <p className="booking-summary-value">
            {selectedTime ? (
              <>
                {selectedTime} ·{" "}
                {provider === "pharmacist" ? "Pharmacist" : "Family doctor"}
              </>
            ) : (
              <span className="booking-summary-placeholder">
                Choose a time to continue
              </span>
            )}
          </p>
        </div>
        <button
          type="button"
          onClick={handleBook}
          disabled={!selectedTime}
          className="btn-primary full-width-sm"
        >
          Confirm appointment
        </button>
      </div>
    </div>
  );
}
