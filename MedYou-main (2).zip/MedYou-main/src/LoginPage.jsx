// src/LoginPage.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./LoginPage.css";

export const LoginPage = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const [status, setStatus] = useState("idle"); // idle | loading | error | success
  const [errorMsg, setErrorMsg] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    setErrorMsg("");

    try {
      const res = await fetch("http://localhost:4000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setStatus("error");
        setErrorMsg(
          data.error || "Login failed. Please check your credentials."
        );
        return;
      }

      const data = await res.json();

      localStorage.setItem("medyou_token", data.token);
      localStorage.setItem("medyou_account", JSON.stringify(data.account));
      localStorage.setItem("medyou_account_email", data.account.email);

      setStatus("success");

      setTimeout(() => {
        navigate("/dashboard");
      }, 700);
    } catch (err) {
      console.error(err);
      setStatus("error");
      setErrorMsg("Network error. Is the MedYou backend running on :4000?");
    }
  };

  return (
    <div className="login-root">
      {/* background orbs, same vibe as signup */}
      <div className="login-orb login-orb--teal" />
      <div className="login-orb login-orb--peach" />
      <div className="login-orb login-orb--mint" />

      <div className="login-card">
        <header className="login-header">
          <div className="login-logo-mark">
            <span>M</span>
          </div>
          <div className="login-logo-text">
            <span>MedYou Health</span>
          </div>
        </header>

        <div className="login-body">
          <h1 className="login-title">Welcome back</h1>
          <p className="login-subtitle">
            Log in to access your MedYou profile.
          </p>

          <div className="login-demo-hint">
            <p className="demo-label">Demo account:</p>
            <p>
              Email: <code>demo@medyou.ca</code>
            </p>
            <p>
              Password: <code>Demo1234!</code>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="login-form">
            <div className="login-field">
              <label htmlFor="email">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                required
                placeholder="you@example.com"
                className="login-input"
              />
            </div>

            <div className="login-field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                required
                placeholder="••••••••"
                className="login-input"
              />
            </div>

            {status === "error" && (
              <div className="login-status login-status--error">
                {errorMsg}
              </div>
            )}

            {status === "success" && (
              <div className="login-status login-status--success">
                Logged in! Redirecting…
              </div>
            )}

            <button
              type="submit"
              className="login-submit"
              disabled={status === "loading"}
            >
              {status === "loading" ? (
                <span className="login-button-content">
                  <span className="login-spinner" />
                  Logging in…
                </span>
              ) : (
                "Log in"
              )}
            </button>
          </form>

          <p className="login-footer">
            New to MedYou? <Link to="/signup">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
};
