// backend/server.js
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 4000;

// ---------- MIDDLEWARE ----------
app.use(
  cors({
    origin: "http://localhost:5173", // Vite dev server
    credentials: true,
  })
);
app.use(express.json());

// ---------- IN-MEMORY DATA STORES ----------

// Sessions: token -> accountId
const sessions = new Map();

// Accounts: accountId -> account object
const accounts = new Map();

// Pre-loaded patients keyed by health card number.
// These are the “real” records your signup links into.
const preloadedPatients = new Map([
    [
      "1234-567-890",
      {
        patientId: "p-1234",
        patient: {
          firstName: "Aisha",
          lastName: "Khan",
          dateOfBirth: "1998-06-15",
          healthCardNumber: "1234-567-890",
        },
        prescriptions: [
          {
            id: "rx-1",
            drug: "Atorvastatin",
            strength: "20 mg",
            directions: "Take 1 tablet by mouth once daily",
            // how many times per day the patient takes it
            dailyDoses: 1,
  
            // NEW: how long this prescription is intended to last
            durationDays: 14,          // e.g. 14-day supply
  
            // NEW: how many pills per dose
            pillsPerDose: 1,           // 1 tablet each time
  
            // NEW: total pills dispensed for this prescription
            // totalPills = dailyDoses * durationDays * pillsPerDose
            totalPills: 14,            // 1 * 14 * 1
  
            // you can still keep a mutable field for remaining pills
            remainingPills: 14,
  
            // optional: dates to help your pill-tracking and history views
            startDate: "2025-03-10",   // when the pack was dispensed
            endDate: "2025-03-23",     // last intended day (inclusive)
  
            prescriber: "Dr. H. Rahman",
            pharmacy: { name: "Shoppers Drug Mart #1234" },
          },
          {
            id: "rx-2",
            drug: "Metformin",
            strength: "500 mg",
            directions: "Take 1 tablet twice daily with food",
            dailyDoses: 2,
  
            // Example of a 7-day prescription
            durationDays: 7,
            pillsPerDose: 1,
            totalPills: 14,            // 2 doses/day * 7 days * 1 pill
  
            remainingPills: 14,
  
            startDate: "2025-03-15",
            endDate: "2025-03-21",
  
            prescriber: "Dr. H. Rahman",
            pharmacy: { name: "Shoppers Drug Mart #1234" },
          },
        ],
        history: [
          {
            id: "hx-1",
            title: "Annual Checkup",
            description: "Routine annual physical exam with bloodwork.",
            type: "appointment",
            date: "2025-03-22",
            recordedAt: "2025-03-22T09:00:00.000Z",
            source: "Family physician",
          },
          {
            id: "hx-2",
            title: "Blood Pressure Follow-up",
            description:
              "Follow-up visit for hypertension, medication adjusted.",
            type: "appointment",
            date: "2025-01-10",
            recordedAt: "2025-01-10T14:30:00.000Z",
            source: "Family physician",
          },
        ],
        closestPharmacy: "Shoppers Drug Mart #1234",
      },
    ],
    [
      "9999-888-777",
      {
        patientId: "p-9999",
        patient: {
          firstName: "Omar",
          lastName: "Patel",
          dateOfBirth: "2000-11-03",
          healthCardNumber: "9999-888-777",
        },
        prescriptions: [
          {
            id: "rx-3",
            drug: "Sertraline",
            strength: "50 mg",
            directions: "Take 1 tablet by mouth once daily in the morning",
            dailyDoses: 1,
  
            // Example of a 28-day (monthly) prescription
            durationDays: 28,
            pillsPerDose: 1,
            totalPills: 28,
  
            remainingPills: 28,
  
            startDate: "2025-04-01",
            endDate: "2025-04-28",
  
            prescriber: "Dr. L. Wong",
            pharmacy: { name: "Rexall Pharmacy #88" },
          },
        ],
        history: [
          {
            id: "hx-3",
            title: "Mental Health Intake",
            description:
              "Initial appointment to assess anxiety and low mood.",
            type: "appointment",
            date: "2025-04-05",
            recordedAt: "2025-04-05T13:00:00.000Z",
            source: "Mental health clinic",
          },
        ],
        closestPharmacy: "Rexall Pharmacy #88",
      },
    ],
  ]);

// Pill log store:
//
// key: `${patientId}:${dateKey}` -> {
//   [rxKey]: {
//     [slotId]: { taken: true, takenAt: ISOString }
//   }
// }
const pillLogStore = new Map();

function getDateKey(date) {
  return (date || new Date()).toISOString().slice(0, 10);
}

function generateToken() {
  return crypto.randomBytes(24).toString("hex");
}

// ---------- AUTH MIDDLEWARE ----------

function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const [scheme, token] = authHeader.split(" ");

  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ error: "Missing or invalid Authorization" });
  }

  const accountId = sessions.get(token);
  if (!accountId) {
    return res.status(401).json({ error: "Invalid session token" });
  }

  const account = accounts.get(accountId);
  if (!account) {
    return res.status(401).json({ error: "Account not found" });
  }

  req.account = account;
  req.token = token;
  next();
}

// ---------- AUTH / ACCOUNT ROUTES ----------

// POST /api/signup
// body: { email, password, healthCardNumber }
app.post("/api/signup", (req, res) => {
  try {
    const { email, password, healthCardNumber } = req.body || {};

    if (!email || !password || !healthCardNumber) {
      return res
        .status(400)
        .json({ error: "email, password, and healthCardNumber are required." });
    }

    // Simple duplication check
    for (const acc of accounts.values()) {
      if (acc.email === email) {
        return res.status(400).json({ error: "Email already registered." });
      }
    }

    const preload = preloadedPatients.get(healthCardNumber);
    if (!preload) {
      return res
        .status(404)
        .json({ error: "No records found for that health card number." });
    }

    const accountId = `acc-${crypto.randomUUID()}`;

    const account = {
      accountId,
      email,
      password, // NOTE: plain text for demo only; hash in real project
      patientId: preload.patientId,
      patient: preload.patient,
      prescriptions: preload.prescriptions,
      history: preload.history,
      closestPharmacy: preload.closestPharmacy,
      createdAt: new Date().toISOString(),
    };

    accounts.set(accountId, account);

    const token = generateToken();
    sessions.set(token, accountId);

    return res.json({
      token,
      account: {
        accountId: account.accountId,
        email: account.email,
        patient: account.patient,
        patientId: account.patientId,
        closestPharmacy: account.closestPharmacy,
      },
    });
  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ error: "Signup failed." });
  }
});

// POST /api/login
// body: { email, password }
app.post("/api/login", (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ error: "email and password are required." });
    }

    let account = null;
    for (const acc of accounts.values()) {
      if (acc.email === email && acc.password === password) {
        account = acc;
        break;
      }
    }

    if (!account) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const token = generateToken();
    sessions.set(token, account.accountId);

    res.json({
      token,
      account: {
        accountId: account.accountId,
        email: account.email,
        patient: account.patient,
        patientId: account.patientId,
        closestPharmacy: account.closestPharmacy,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed." });
  }
});

// GET /api/me
// Returns current account profile (without password)
app.get("/api/me", requireAuth, (req, res) => {
  const acc = req.account;
  res.json({
    accountId: acc.accountId,
    email: acc.email,
    patient: acc.patient,
    patientId: acc.patientId,
    closestPharmacy: acc.closestPharmacy,
    createdAt: acc.createdAt,
  });
});

// ---------- CLINICAL DATA ROUTES ----------

// GET /api/me/prescriptions
app.get("/api/me/prescriptions", requireAuth, (req, res) => {
  try {
    const acc = req.account;
    res.json({
      prescriptions: acc.prescriptions || [],
    });
  } catch (err) {
    console.error("Prescriptions error:", err);
    res.status(500).json({ error: "Could not load prescriptions." });
  }
});

// GET /api/me/history
app.get("/api/me/history", requireAuth, (req, res) => {
  try {
    const acc = req.account;
    res.json({
      history: acc.history || [],
    });
  } catch (err) {
    console.error("History error:", err);
    res.status(500).json({ error: "Could not load history." });
  }
});

// ---------- PILL TRACKING ROUTES ----------

// GET /api/me/pill-log?date=YYYY-MM-DD
app.get("/api/me/pill-log", requireAuth, (req, res) => {
  try {
    const dateKey = (req.query.date || getDateKey()).toString();
    const storeKey = `${req.account.patientId}:${dateKey}`;
    const log = pillLogStore.get(storeKey) || {};
    res.json({ date: dateKey, log });
  } catch (err) {
    console.error("Pill log GET error:", err);
    res.status(500).json({ error: "Could not fetch pill log." });
  }
});

// POST /api/me/pill-log
// body: { date?: string, rxKey: string, slotId: string, taken: boolean }
app.post("/api/me/pill-log", requireAuth, (req, res) => {
  try {
    const { date, rxKey, slotId, taken } = req.body || {};

    if (!rxKey || !slotId) {
      return res
        .status(400)
        .json({ error: "rxKey and slotId are required." });
    }

    const dateKey = (date || getDateKey()).toString();
    const storeKey = `${req.account.patientId}:${dateKey}`;

    const currentDay = pillLogStore.get(storeKey) || {};
    const rxLog = currentDay[rxKey] || {};
    const nextTaken = Boolean(taken);

    if (nextTaken) {
      rxLog[slotId] = {
        taken: true,
        takenAt: new Date().toISOString(),
      };
    } else {
      delete rxLog[slotId];
    }

    const nextDay = { ...currentDay, [rxKey]: rxLog };
    pillLogStore.set(storeKey, nextDay);

    res.json({ ok: true, date: dateKey, log: nextDay });
  } catch (err) {
    console.error("Pill log POST error:", err);
    res.status(500).json({ error: "Could not update pill log." });
  }
});

// ---------- BASIC HEALTH CHECK ----------
app.get("/", (req, res) => {
  res.json({ ok: true, service: "MedYou API", time: new Date().toISOString() });
});

// ---------- START SERVER ----------
app.listen(PORT, () => {
  console.log(`MedYou API listening on http://localhost:${PORT}`);
});